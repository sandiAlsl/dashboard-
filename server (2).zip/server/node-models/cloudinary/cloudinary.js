module.exports = require('./lib/cloudinary');
