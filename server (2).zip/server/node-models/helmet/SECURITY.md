# Security issue reporting & disclosure process

If you feel you have found a security issue or concern with Helmet, please reach out to the maintainers.

Contact Evan Hahn at <me@evanhahn.com> or Adam Baldwin at <adam@npmjs.com>. Evan Hahn [can also be reached in other ways](https://evanhahn.com/contact).

We will try to communicate in a timely manner and address your concerns.
